const About = () => {
    return (
    <div className="alert alert-primary" role="alert">
        <h1>About us</h1>
    </div>      
                
    );
}

export default About;