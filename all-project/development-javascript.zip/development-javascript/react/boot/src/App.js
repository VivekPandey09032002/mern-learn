import Header from "./component/Header";
import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
function App() {
  return (
    <div>
      <Header/>
      <Contact/>
      :fire:
    </div>  

  );
}

export default App;
