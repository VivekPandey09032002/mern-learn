import React from 'react'

function Player() {
  return (
    <div>Welcome to spotify</div>
  )
}

export default Player