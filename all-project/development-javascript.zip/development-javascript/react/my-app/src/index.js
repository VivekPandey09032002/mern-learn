import ReactDom from 'react-dom'
import React from "react";
import './index.css' 
import App from './App'

ReactDom.render(<App />,document.getElementById('root'))