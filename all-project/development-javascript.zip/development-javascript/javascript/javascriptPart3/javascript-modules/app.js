import {firstName as fname} from './utils/fname'
import {age} from './utils/age'

console.log('ehllo')
console.log(fname,age)