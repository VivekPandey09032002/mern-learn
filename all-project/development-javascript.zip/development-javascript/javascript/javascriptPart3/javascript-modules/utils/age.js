const age = 22

export {age}