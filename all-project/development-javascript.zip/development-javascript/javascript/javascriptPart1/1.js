// let 
/*
var firstName = 'vivek'
var firstName = 'vishal'
console.log(firstName)
*/
// cannot redeclare
let firstName = 'vivek'
// let firstName = 'vishal'  //err
firstName = 'vishal'
console.log(firstName)