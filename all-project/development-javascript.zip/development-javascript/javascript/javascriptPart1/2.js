//const
const  PI = 3.14;
// PI = 2;  // err
console.log(PI)