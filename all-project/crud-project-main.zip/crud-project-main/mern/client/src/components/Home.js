import React from "react";

const Home = () => {
  return (
    <>
      <div className="home-page">
        <div className="home-div">
          <p className="pt-5">WELCOME</p>
          <h1>We are The MERN DEVELOPER</h1>
        </div>
      </div>
    </>
  );
};

export default Home;
