const skillController = (req,res) => {
    res.render('skill', {title : 'skill'})
}

export {skillController}