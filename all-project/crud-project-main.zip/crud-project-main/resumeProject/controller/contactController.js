const contactController = (req,res) => {
    res.render('contact', {title : 'contact'})
}

export {contactController}