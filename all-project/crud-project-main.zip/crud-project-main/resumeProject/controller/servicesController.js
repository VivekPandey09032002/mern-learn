const servicesController = (req,res) => {
    res.render('services', {title : 'services'})
}

export {servicesController}