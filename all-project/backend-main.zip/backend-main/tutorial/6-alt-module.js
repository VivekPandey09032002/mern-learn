module.exports.items = ['item1', 'item2'];
const person = {
    name : 'vivek'
}

module.exports.singlePerson = person;