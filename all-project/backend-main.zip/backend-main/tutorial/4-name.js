//local
const secret = 'Super Secret';
//shared
const vivek = 'vivek pandey';
const vishal = 'vishal pandey';

module.exports = { vivek : vivek,vishal : vishal};